﻿namespace DitFlo.Models
{
    public class HomeViewModel
    {
        public string Name { get; set; }
    }
}
