﻿namespace DitFlo.Models
{
    public class TestPartialViewModel
    {
        public string MyProp { get; set; }
    }
}
