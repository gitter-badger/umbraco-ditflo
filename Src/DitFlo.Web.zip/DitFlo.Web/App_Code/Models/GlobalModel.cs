﻿using Our.Umbraco.Ditto;

namespace DitFlo.Models
{
    [UmbracoProperties(Recursive = true)]
    public class GlobalModel
    {
        public string SiteTitle { get; set; }
        public string SiteDescription { get; set; }
        public string SiteLogo { get; set; }

        [DittoIgnore]
        public string SiteUrl { get; set; }
    }
}
