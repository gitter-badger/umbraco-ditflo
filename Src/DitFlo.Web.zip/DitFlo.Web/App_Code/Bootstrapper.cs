﻿using DitFlo.Models;
using Our.Umbraco.Ditto;
using Umbraco.Core;
using Umbraco.Web;

namespace DitFlo
{
    public class Bootstrapper : ApplicationEventHandler
    {
        protected override void ApplicationStarted(UmbracoApplicationBase umbracoApplication, ApplicationContext applicationContext)
        {
            EventHandlers.ConvertedType += (sender, args) =>
            {
                if (typeof(GlobalModel).IsAssignableFrom(args.ConvertedType))
                {
                    var model = (GlobalModel)args.Converted;

                    model.SiteUrl = args.Content.AncestorOrSelf(1).Url;
                }
            };
        }
    }
}
